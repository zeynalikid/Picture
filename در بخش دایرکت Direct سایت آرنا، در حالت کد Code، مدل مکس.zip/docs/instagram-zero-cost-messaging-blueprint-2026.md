# راهنمای جامع پیام‌رسانی اینستاگرام با هزینه صفر (Zero-Cost) — ۲۰۲۶

> **پروژه:** ربات تلگرام (Python/FastAPI) روی Vercel + دیتابیس Supabase، برای مدیریت پیج ‎@zeynalikids
> **تاریخ تحقیق:** مهر ۱۴۰۵ / اکتبر ۲۰۲۶
> **روش تحقیق:** بررسی مستقیم صفحات قیمت‌گذاری و مستندات رسمی پلتفرم‌ها (منابع در انتهای سند)
> **نتیجه نهایی:** معماری کاملاً رایگان و قابل پیاده‌سازی روی Vercel + Supabase، بدون حتی ۱ دلار هزینه

---

## فهرست مطالب

1. [خلاصه مدیریتی (TL;DR)](#1-خلاصه-مدیریتی)
2. [وضعیت بازار در ۲۰۲۶ — چرا فضا تغییر کرده](#2-وضعیت-بازار-در-۲۰۲۶)
3. [پاسخ سؤال ۱: جایگزین رایگان ChatbotX](#3-پاسخ-سؤال-۱-جایگزین-رایگان-chatbotx)
4. [پاسخ سؤال ۲: خواندن و پاسخ پیام با اپ‌های تأییدشده‌ی اشخاص ثالث](#4-پاسخ-سؤال-۲-پیام‌رسانی-از-طریق-اپ‌های-تأییدشده-بدون-اپ-متا)
5. [پاسخ سؤال ۳: معماری Serverless با LLM رایگان (و بحث MCP)](#5-پاسخ-سؤال-۳-معماری-serverless--llm-رایگان)
6. [پاسخ سؤال ۴: تحلیل ریسک و هزینه Zernio و استراتژی ماندن زیر ۱۰٬۰۰۰ پیام](#6-پاسخ-سؤال-۴-تحلیل-ریسک-و-هزینه-zernio--استراتژی-ماندن-زیر-۱۰۰۰۰-پیام)
7. [پاسخ سؤال ۵: پل (Bridge) کاملاً رایگان و نامحدود با تلگرام](#7-پاسخ-سؤال-۵-پل-رایگان-تلگرام--اینستاگرام)
8. [جدول مقایسه‌ی ۳ گزینه برتر](#8-جدول-مقایسه-۳-گزینه-برتر)
9. [معماری فنی پیشنهادی (نقشه پیاده‌سازی کامل)](#9-معماری-فنی-پیشنهادی-نقشه-پیاده‌سازی-کامل)
10. [ریسک‌ها، محدودیت‌های پلتفرمی و نکات صریح](#10-ریسک‌ها-و-محدودیت‌های-پلتفرمی)
11. [منابع و مناقبات](#11-منابع)

---

## 1. خلاصه مدیریتی

| سؤال | پاسخ کوتاه |
|---|---|
| جایگزین رایگان ChatbotX با API وجود دارد؟ | **بله، فقط یک گزینه واقعی دارد: Zernio** (همان سرویسی که دارید). پلن رایگانش شامل Inbox کامل، وب‌هوک و API می‌شود. SocialAPI.ai هم پلن رایگان دارد اما فقط ۵۰ پیام ارسالی در ماه. بقیه (Ayrshare, Buffer, Publer) برای پیام‌رسانی رایگان نیستند. |
| آیا می‌شود بدون اپ متا پیام خواند/فرستاد؟ | **بله.** وب‌هوک‌های Zernio پیام‌های ورودی را **رایگان و نامحدود** به Vercel شما پوش می‌کنند. خواندن پیام همیشه رایگان است؛ فقط «پیام‌های ارسالی» متر می‌شوند. |
| راه حل Serverless با LLM رایگان؟ | **بله.** Webhook → Vercel → Supabase (صف) → Gemini/Groq/Mistral (لایه رایگان) → ارسال با یک `POST` به Zernio. نیازی به MCP نیست (MCP فقط یک لایه دسترسی دیگر به همان API است و معجزه‌ای در هزینه نمی‌کند). |
| چطور زیر ۱۰٬۰۰۰ پیام بمانیم؟ | با سه اهرم: (۱) **پاسخ به کامنت‌ها کاملاً رایگان و نامحدود است** — مترجم هزینه فقط دایرکت‌های ارسالی است؛ (۲) فیلتر هوشمند اسپم/تکراری/کول‌داون در Supabase؛ (۳) **قابلیت Hard-Cap**: اگر کارتی به Zernio ندهید، در مرز ۱۰٬۰۰۰ ارسال‌ها متوقف می‌شوند و **هیچ صورتحسابی غیرممکن است**. |
| پل رایگان نامحدود؟ | **بله — «تقسیم کانال»:** خواندن نامحدود است (رایگان)، پاسخ به کامنت نامحدود است (رایگان)، و برای دایرکت‌ها از **پل انسانی تلگرام** + پاسخ‌گوی LLM با بودجه‌ی ۱۰هزار استفاده کنید. ترکیبش عملاً نامحدود است. |

**معماری برنده (۰ دلار):**

```
Instagram ──(وب‌هوک Zernio، رایگان و نامحدود)──▶ Vercel/FastAPI
    ▲                                                  │
    │                     ┌────────────────────────────┤
    │                     ▼                            ▼
    │              فیلتر اسپم/تکراری            صف در Supabase
    │              (SQL، رایگان)                       │
    │                     │                            ▼
    │                     │                   تصمیم‌گیر (Decision Layer):
    │                     │                   کامنت؟ → پاسخ عمومی (نامحدود/رایگان)
    │                     │                   دایرکت؟ → Template یا LLM رایگان
    │                     │                   بودجه تمام؟ → پل انسانی تلگرام
    │                     │                            │
    └──────(ارسال از طریق Zernio API، زیر ۱۰هزار/ماه)◀┘
```

---

## 2. وضعیت بازار در ۲۰۲۶ — چرا فضا تغییر کرده

سه تغییر ساختاری که این پاسخ را از هر راهنمای قدیمی متمایز می‌کند:

1. **از ۱ اکتبر ۲۰۲۶، Zernio مدل قیمت‌گذاری‌اش را عوض کرد و پلن‌های طبقه‌ای را حذف کرد.** حالا هر اکانت متصل، «همه‌ی قابلیت‌ها» را دارد: انتشار نامحدود، Inbox (دایرکت + کامنت)، وب‌هوک، MCP Server، CLI و SDK. **۲ اکانت اول به طور دائم رایگان است، بدون کارت بانکی.** تنها چیز مترشده: **پیام‌های ارسالی** — ۱۰٬۰۰۰ عدد اول هر ماه رایگان، بعد از آن ۰٫۰۰۰۱ دلار به ازای هر پیام (۱ دلار به ازای هر ۱۰٬۰۰۰).
   (منابع: [zernio.com/pricing](https://zernio.com/pricing)، [docs.zernio.com/pricing](https://docs.zernio.com/pricing)، [zernio.com/blog/pay-per-account-pricing](https://zernio.com/blog/pay-per-account-pricing))

2. **یک بازیکن جدید با پلن رایگان آمده: SocialAPI.ai** (از آوریل ۲۰۲۶ روی اینستاگرام فعال است، با ۴ اسکوپ تأییدشده‌ی متا شامل `instagram_business_manage_messages`). پلن Hobby: ۰ دلار، ۲ پروفایل، ۱۰ پست/ماه و **۵۰ interaction در ماه** (ارسال دایرکت هم یک interaction محسوب می‌شود). خواندن کامنت/دایرکت/منشن **رایگان و نامحدود** — اما ۵۰ ارسال در ماه برای حجم شما کافی نیست.
   (منبع: [social-api.ai/pricing](https://social-api.ai/pricing))

3. **ابزارهای comment-to-DM رایگان زیاد شده‌اند** (QuickDM با ۲۰ دایرکت در ساعت رایگان، ReplyRush با ۱۵۰۰ دایرکت/ماه، LinkDM با ۱۰۰۰ دایرکت/ماه...) اما هیچ‌کدام در پلن رایگان **API یا Webhook عمومی** نمی‌دهند؛ یعنی با ربات تلگرام/LLM شما یکپارچه نمی‌شوند. برای «پاسخ LLM محور» فقط سرویس‌های API-first یعنی Zernio و SocialAPI.ai کاندید هستند.

**نکته‌ی کلیدی درباره‌ی ChatbotX (سرویس فعلی شما):** طبق صفحه‌ی قیمت‌گذاری ۲۰۲۶ آن‌ها، پلن COMMUNITY رایگان است اما **فقط Self-Hosted** (نیازمند VPS — که شما ندارید). پلن‌های ابری‌اش از ۲۹ دلار (LITE، سقف ۱۰هزار bot message) شروع می‌شود و فقط ۷ روز تریال دارد. پس «تریال تمام‌شده‌ی» شما واقعاً راه رایگانی در خود ChatbotX ندارد. جالب است که در مدل ChatbotX حتی «typing indicator» و «delay step» هم یک bot message محاسبه می‌شود — مدل شمارش Zernio بسیار منصفانه‌تر است (فقط پیام واقعی ارسال‌شده).
(منابع: [chatbotx.io/pricing](https://chatbotx.io/pricing/)، [chatbotx.io/channels/instagram](https://chatbotx.io/channels/instagram/))

---

## 3. پاسخ سؤال ۱: جایگزین رایگان ChatbotX

### 3.1 جدول کامل گزینه‌ها با محدودیت دقیق پلن رایگان (وضعیت اکتبر ۲۰۲۶)

| سرویس | پلن رایگان دائمی؟ | دایرکت/کامنت در پلن رایگان؟ | API/Webhook در پلن رایگان؟ | سقف پیام رایگان | خود اپ متا را تأیید کرده؟ | حکم برای شما |
|---|---|---|---|---|---|---|
| **Zernio** | بله (۲ اکانت، بدون کارت) | بله — Inbox کامل | **بله — API + Webhook + MCP کامل** | **۱۰٬۰۰۰ ارسال/ماه**؛ دریافت و پاسخ‌به‌کامنت نامحدود | بله | **بهترین و تنها گزینه API-first رایگان** |
| **SocialAPI.ai** | بله (Hobby، بدون کارت) | بله | بله — API + Webhook + MCP | فقط **۵۰ ارسال/ماه** (دریافت نامحدود) | بله | مکمل/رزرو؛ برای سیلو (failover) خواندن |
| **QuickDM** | بله | بله (comment-to-DM، auto-reply) | **خیر** (ابزار no-code) | ۲۰ دایرکت/ساعت (≈ ۴۸۰/روز تکنیکی) | بله (Graph API) | خوب برای کمپین‌های کلیدواژه‌ای، بدون LLM |
| **ReplyRush** | بله | بله | خیر (در پلن رایگان) | ۱٬۵۰۰ دایرکت/ماه | بله | فallback no-code |
| **LinkDM** | بله | بله | خیر | ۱٬۰۰۰ دایرکت/ماه | بله (Meta Business Partner) | fallback no-code |
| **LinkToDM** | بله | بله | خیر | ۲٬۰۰۰ دایرکت/ماه، ۲ اکانت | بله | fallback no-code |
| **CreatorFlow** | بله (با کارت) | بله | خیر | ۵۰۰ دایرکت/ماه | بله (Meta Tech Provider) | ضعیف برای حجم شما |
| **InstantDM** | خیر (تریال ۷ روزه) | — | — | — | بله | ۹٫۹۹$/ماه نامحدود — اولین گزینه‌ی پولی ارزان |
| **ManyChat** | بله، ولی از مارس ۲۰۲۶ فقط **۲۵ مخاطب فعال/ماه** | بسیار محدود | خیر در پلن رایگان | عملاً صفر برای شما | بله | رد (خودتان هم حذفش کردید) |
| **Ayrshare** | **خیر** (فقط تریال ۲۸ روزه) | فقط در پلن‌های پولی | تریال Launch | پلن Premium: ۱۴۹$/ماه + **افزونه‌ی ۴۹$/ماه** برای Messaging، یا ۰٫۰۹$ به ازای هر مکالمه فعال | بله | **رد قطعی** — گران‌ترین مسیر |
| **Buffer** | بله (۳ کانال، ۱۰ پست در صف) | **خیر** — Inbox آن UI است؛ API آن فقط انتشار | بله، اما API فقط پست/اسケژول + ۱ کلید/۳٬۰۰۰ ریکوئست در ۳۰ روز | نامحدود برای پست، صفر برای پیام | بله | برای پیام‌رسانی **بلیس است** |
| **Publer** | بله (۳ اکانت، بدون X) | **خیر** | **خیر** — API فقط برای مشتریان Business/Enterprise | صفر برای پیام | بله | رد — API در پلن رایگان نیست |
| Meta Business Suite | بله (رسمی خود متا) | بله — اما **دستی** | خیر (بدون اپ متا Webhook/API ندارد) | نامحدود دستی | خود متا | مکمل رایگان برای پاسخ انسانی؛ محدود: ۵ کلیدواژه، تأخیر ۱۵ دقیقه‌ای |
| Chatfuel | خیر (تریال) | — | — | Business از ۲۰$/ماه | بله | رد |
| Open-source تازه‌ها (OpenReply, ZernFlow, InstaAuto) | بله (کد رایگان) | بله | بله | نامحدود | **خیر — باید خودتان اپ متا بسازید + سرور بگیرید** (هزینه‌ی عملیاتی ۲۶ تا ۶۳$/ماه) | رد (دو درِ بسته‌ی شما را هم‌زمان می‌شکند) |

> منابع بخش: [Ayrshare pricing](https://www.ayrshare.com/pricing/) و [messenger APIs](https://www.ayrshare.com/social-media-messenger-apis/)، [تحلیل مستقل Ayrshare 2026](https://social-api.ai/blog/ayrshare-pricing-social-media-api-2026)، [Buffer API help](https://support.buffer.com/article/859-does-buffer-have-an-api) و [buffer.com/api](https://buffer.com/api)، [Publer plans](https://publer.com/help/en/article/what-are-publers-plans-and-pricing-15h4yqh/)، [QuickDM](https://quickdm.app/blog/best-instagram-dm-automation-tools)، [مقایسه ۹ ابزار ReelDrop](https://www.reeldrop.io/blog/best-instagram-dm-automation-tools/)، [مقایسه پلن‌های رایگان CreatorFlow](https://creatorflow.so/blog/free-instagram-dm-automation-tools/)، [Blotato ManyChat](https://www.blotato.com/blog/instagram-automation-tools)، [Open source Instagram DM cost](https://creatorflow.so/blog/open-source-instagram-dm-automation/)

### 3.2 نتیجه‌ی سؤال ۱

> **جایگزین کاملاً رایگان ChatbotX که هم پلن رایگان دائمی داشته باشد، هم API/Webhook بدهد و هم بدون اپ متا کار کند، دقیقاً یک عدد است: Zernio (که همین حالا هم دارید).** SocialAPI.ai دومین گزینه است اما سقف ۵۰ ارسال/ماه آن را فقط به «لایه‌ی خواندن رزرو» تبدیل می‌کند. بقیه‌ی ابزارهای رایگان (QuickDM و هم‌قطارانش) پاسخ‌گوی LLM-محور شما نیستند چون API نمی‌دهند — اما در §۷ یک ترفند خلاقانه برای استفاده‌ی موازی از آن‌ها می‌آید.

---

## 4. پاسخ سؤال ۲: پیام‌رسانی از طریق اپ‌های تأییدشده بدون اپ متا

### 4.1 چرا قانوناً ممکن است

متا برای دادن دسترسی پیام‌رسانی به اکانت‌هایی که مالکش نیستید، **App Review + Business Verification + Advanced Access** می‌خواهد. Zernio و SocialAPI.ai این مراحل را برای **اپ خودشان** پاس کرده‌اند؛ شما با OAuth به اپ **آن‌ها** وصل می‌شوید و هیچ چیزی سابمیت نمی‌کنید. این دقیقاً همان راهی است که الان برای پست‌گذاری استفاده می‌کنید — فقط به Inbox تعمیم می‌یابد.
(منبع: [Instagram & Facebook API Without Meta App Review (2026)](https://social-api.ai/blog/instagram-facebook-api-without-meta-app-review))

### 4.2 Zernio چه چیزی را رایگان به Vercel شما پوش می‌کند

طبق مستندات Inbox Webhooks، Zernio رویدادهای زیر را به اندپوینت شما `POST` می‌کند (اشتراک با `POST /v1/webhooks/settings` و سکرت امضایی که **خود شما تعریف می‌کنید**):

| رویداد | معنی | هزینه |
|---|---|---|
| `message.received` | دایرکت ورودی جدید | **رایگان، نامحدود** |
| `comment.received` | کامنت جدید روی پست‌های ردیابی‌شده | **رایگان، نامحدود** |
| `conversation.started` | شروع مکالمه‌ی جدید (یک بار به ازای هر مکالمه) | رایگان |
| `reaction.received` | ری‌اکشن ایموجی (جدا از پیام ارسال می‌شود تا با دایرکت قاطی نشود) | رایگان |
| `message.read / edited / deleted` | چرخه‌ی عمر پیام (اینستاگرام unsend هم پوشش داده شده) | رایگان |
| `referral.received` | ورود از لینک ig.me/m.me | رایگان |
| `message.sent / delivered / failed` | وضعیت پیام‌های خروجی خودتان | رایگان (رویداد؛ نه خود پیام) |

**سه قابلیت طلایی که فرار هوشمندانه از هزینه را ممکن می‌کند:**

1. **خواندن همیشه رایگان است** — حجم ورودی شما (۱۵ تا ۳۰ هزار پیام در ماه) هیچ هزینه‌ای ندارد.
2. **پاسخ به کامنت‌ها متر نمی‌شود** — «Reading and replying to comments is unmetered. Only DMs you send count toward the 10,000/month message allowance.» یعنی می‌توانید **نامحدود** به کامنت‌ها ریپلای عمومی بزنید، کامنت اسپم را hide/delete کنید، و این‌ها جزو ۱۰هزارتا حساب نمی‌شود.
   (منابع: [zernio.com/social-media-comments](https://zernio.com/social-media-comments)، [docs.zernio.com/pricing](https://docs.zernio.com/pricing)، [droidcrunch Zernio pricing](https://droidcrunch.com/zernio-pricing/))
3. **ریپلی تاریخچه** — موقع کانکت، Zernio تا ۵۰۰ مکالمه‌ی آخر (هر کدام تا ۵۰۰ پیام) را از متا سینک می‌کند؛ یعنی حتی مکالمه‌های قبل از اتصال را هم دارید و برای لود تاریخچه هزینه‌ای نمی‌دهید.
   (منبع: [docs.zernio.com/platforms/instagram](https://docs.zernio.com/platforms/instagram))

### 4.3 پاسخ مستقیم سؤال شما درباره‌ی «لایه‌ی فرار از هزینه»

> **بله، دقیقاً همان چیزی که حدس زدید وجود دارد:** وب‌هوک Zernio پیام‌ها را رایگان به Vercel می‌فرستد، شما در Supabase تصمیم می‌گیرید، و فقط برای «ارسال دایرکت» به Zernio برمی‌گردید. تمام منطق میانی (فیلتر، LLM، صف) روی زیرساخت رایگان شماست. تنها نقطه‌ی مترشده‌ی کل سیستم، تابع `send()` است — و کل §۶ این سند به چگونگی محافظت از همان یک تابع اختصاص دارد.

---

## 5. پاسخ سؤال ۳: معماری Serverless + LLM رایگان (و بحث MCP)

### 5.1 آن «یک درخواست GET/POST رایگان» چیست؟

ارسال پاسخ به اینستاگرام در نهایت تبدیل به **یک `POST` ساده** می‌شود — اندپوینت ارسال پیام Zernio (معادل CLI: `zernio inbox:send <conversationId>`). نیازی به سرور MCP جداگانه نیست. توضیح شفاف درباره‌ی MCP:

- **Zernio MCP** (`mcp.zernio.com/mcp`) و **SocialAPI MCP** (۷۵ ابزار) هر دو **رایگان** در پلن صفر هستند، اما این را بدانید: MCP فقط یک **پروتکل دسترسی** برای ایجنت‌هاست؛ «Tool calls bill like the API requests behind them» — یعنی ارسال پیام از مسیر MCP هم همان سهمیه‌ی ۱۰هزارتایی را مصرف می‌کند. **هیچ سرور MCP رایگانی در جهان نمی‌تواند محدودیت ارسال اینستاگرام را دور بزند**، چون محدودیت در لایه‌ی متا/پروایدر است نه در لایه‌ی پروتکل.
- MCP برای شما جاهای دیگری کاربرد دارد: اتصال Claude/Cursor به Inbox برای «اپراتور انسانیِ کمک‌گرفته از AI». اما برای پایپ‌لاین خودکار سرورلس، **REST خالص ساده‌تر، سریع‌تر و دیباگ‌پذیرتر است.**

(منابع: [zernio.com/instagram-mcp](https://zernio.com/instagram-mcp)، [social-api.ai/best-social-media-api-ai-agents](https://social-api.ai/blog/best-social-media-api-mcp))

### 5.2 LLM رایگان — جدول لایه‌های صفرهزینه (اکتبر ۲۰۲۶)

| پروایدر | مدل‌های رایگان | سقف رایگان | کارت لازم؟ | نکته |
|---|---|---|---|---|
| **Google AI Studio (Gemini)** | Flash / Flash-Lite (و تا قبل آوریل ۲۰۲۶ پرو) | ≈ **۵۰۰–۱۵۰۰ درخواست/روز**، ۱۰–۱۵ RPM (عدد دقیق در داشبورد AI Studio هر پروژه نمایش داده می‌شود؛ گوگل دیگر جدول ثابت منتشر نمی‌کند) | خیر | **گزینه‌ی اصلی**؛ داده‌های لایه رایگان ممکن است برای آموزش استفاده شود (برای چت پشتیبانی فروشگاه بچه‌گانه ریسک حریم خصوصی پایین است، ولی بدانید) |
| **Groq** | GPT-OSS-120B/20B، Qwen | ۳۰ RPM / **۱٬۰۰۰ درخواست/روز**، ۲۰۰هزار توکن/روز | خیر | **فallback اول** — نمونه‌سازی از OpenAI-compatible API |
| **Mistral (La Plateforme، تییر Experiment/Free)** | Mistral Small و... | حدود ۱ req/s (≈ **۲٬۰۰۰ درخواست/روز** عملیاتی) | خیر | fallback دوم |
| OpenRouter (`:free` مدل‌ها) | چند مدل | ۵۰ درخواست/روز (۱۰۰۰ با ۱۰ دلار اعتبار) | خیر | فقط fallback اضطراری |

> ظرفیت ترکیبی ≈ **۳٬۵۰۰+ پاسخ LLM در روز** — یعنی حتی اگر ۱۰۰٪ پیام‌های شما نیاز به تولید متن LLM داشته باشند (۵۰۰ تا ۱٬۰۰۰ در روز)، سه برابر حاشیه امنیت دارید. در عمل با تمپلیت‌های FAQ (§۶) نیاز روزانه به LLM به ۲۰۰ تا ۴۰۰ درخواست می‌رسد.

(منابع: [TokenMix Gemini free tier](https://tokenmix.ai/blog/gemini-api-free-tier-limits)، [Memetik Gemini limits](https://www.memetik.ai/guides/gemini-api-free-tier-limits)، [OpenRouter free LLM APIs](https://openrouter.ai/blog/tutorials/free-llm-apis-compared/)، [Eden AI free APIs](https://www.edenai.co/post/top-free-generative-ai-apis-and-open-source-models))

### 5.3 زیرساخت صفرهزینه — آیا Vercel + Supabase تحمل می‌کند؟

| منبع | سقف رایگان | مصرف تخمینی شما | وضعیت |
|---|---|---|---|
| Vercel Hobby — Function Invocations | ۱٬۰۰۰٬۰۰۰/ماه | ~۴۰٬۰۰۰–۷۰٬۰۰۰ (وب‌هوک + صف + تلگرام) | سبز |
| Vercel Hobby — Active CPU | ۴ ساعت CPU/ماه | پردازش سبک webhook (هرکدام <۱ ثانیه CPU) | سبز، ولی مراقب دانلود مدیا باشید |
| Vercel Hobby — Cron | ۱۰۰ جاب، ولی **هر جاب حداکثر ۱ بار در روز** و تا ۵۹ دقیقه تأخیر | گزارش روزانه + آمار استفاده | سبز برای گزارش؛ **برای تخلیه‌ی صف کافی نیست** → در §۹ حلش می‌کنیم |
| Supabase Free | ۵۰۰ مگ دیتابیس، ۵ گیگ egress، ۵۰۰هزار Edge Function/ماه، API نخورده | چند صد هزار ردیف پیام/لاگ، چند مگابایت | سبز؛ می‌خورد بعد ۷ روز عدم‌فعالیت Pause شود — ترافیک وب‌هوک جلویش را می‌گیرد |
| Telegram Bot API | **کاملاً رایگان و نامحدود** (حد نرخ ۳۰ پیام/ثانیه) | چند صد پیام ادمین/روز | سبز |

**هشدار صادقانه‌ی معماری (مهم):** شرایط Vercel Hobby از نظر قانونی «غیرتجاری/شخصی» است. برای یک پیج فروشگاهی (@zeynalikids) این یک ریسک Terms-of-Service است نه ریسک فنی. دو راه صفرهزینه‌ی دفاعی: (الف) پردازش وب‌هوک را به **Supabase Edge Functions** منتقل کنید (۵۰۰هزار فراخوانی/ماه رایگان، محدودیت تجاری ندارد، Deno/TypeScript) و Vercel را فقط برای ربات تلگرام نگه دارید؛ یا (ب) ریسک را بپذیرید و در صورت رشد، Pro را ۲۰ دلار ببینید. بقیه‌ی سند با فرض Vercel/FastAPI فعلی شما نوشته می‌شود چون خواسته‌ی شما بود، اما گزینه‌ی (الف) تمیزترین مسیر صفرِ-کاملاً-قانونی است.
(منابع: [Vercel Hobby docs](https://vercel.com/docs/plans/hobby)، [Vercel cron pricing](https://vercel.com/docs/cron-jobs/usage-and-pricing)، [Supabase pricing](https://supabase.com/pricing)، [Supabase functions limits](https://supabase.com/docs/guides/functions/limits))

---

## 6. پاسخ سؤال ۴: تحلیل ریسک و هزینه Zernio + ماندن زیر ۱۰٬۰۰۰ پیام/ماه

### 6.1 مدل متر Zernio را دقیق بفهمیم (اکتبر ۲۰۲۶)

| چه چیزی | آیا متر می‌شود؟ | سقف رایگان | بعد از سقف |
|---|---|---|---|
| پیام‌های **دریافتی** (دایرکت/کامنت) | خیر | نامحدود | همیشه رایگان |
| **ریپلای عمومی به کامنت**، hide/unhide، delete کامنت | خیر | نامحدود | همیشه رایگان |
| پاسخ به Review | خیر | نامحدود | همیشه رایگان |
| **دایرکت ارسالی** (ریپلای، پیام اول، broadcast به ازای هر گیرنده، پیام‌های workflow/comment-to-DM) | **بله** | ۱۰٬۰۰۰/ماه برای کل تیم | ۰٫۰۰۰۱$/پیام (=۱$ به ازای ۱۰هزار) |
| پست/استوری/ریلز منتشرشده | خیر | نامحدود | رایگان |

دو واقعیت محاسباتی مهم:
- خوش‌بینانه‌ترین حالت شما (۵۰۰ پیام/روز ورودی، همه دایرکت، پاسخ به همه): ≈ ۱۵٬۰۰۰ ارسال/ماه → **مازاد ≈ ۰٫۵ دلار**. بدترین حالت (۱٬۰۰۰/روز): ≈ ۳۰٬۰۰۰ ارسال → **مازاد ≈ ۲ دلار**. یعنی حتی بدون هیچ بهینه‌سازی، تابستان سال سخت است بیش از ۲۴ دلار در سال! اما هدف ما صفر مطلق است → ادامه.
- **تأمین‌کننده‌ی صفرِ تضمینی:** طبق سیاست رسمی، اگر **کارت بانکی به اکانت ندهید**، Zernio در ۷٬۵۰۰ پیام ایمیل هشدار می‌فرستد و در ۱۰٬۰۰۰ **ارسال‌های بعدی تا اول ماه بعد Fail می‌شوند** در حالی که خواندن، آنالیتیکس و انتشار به کارشان ادامه می‌دهد. یعنی **صورتحساب از نظر فیزیکی غیرممکن است** — متر شما «فیوز» دارد.
(منبع: [droidcrunch Zernio pricing](https://droidcrunch.com/zernio-pricing/) — نقل از مکانیزم هشدار/توقف؛ [docs.zernio.com/pricing](https://docs.zernio.com/pricing))

### 6.2 آیا Zernio خودش تشخیص پیام تکراری/بلاک دارد؟

**خیر — به شکل «لایه‌ی سیاست‌گذاری» نه، و این کار شماست.** Zernio این‌ها را دارد:
- ✅ Dedupe در لایه‌ی وب‌هوک (رویدادها با id مشخص می‌آیند و راهنمای retry/deduplicate در مستندات است؛ شما با ذخیره‌ی `event_id` در Supabase جلوی پردازش دوباره را می‌گیرید)
- ✅ `excludeKeywords`، `typoTolerance` و `matchMode` در Comment-to-DM automations
- ✅ جدا کردن `reaction.received` از `message.received` (تا برای «❤️» خالی دایرکت نفرستید)
- ❌ Blocklist کاربر، کول‌داون مکالمه، تشخیص سلام/اسپم فارسی، بودجه‌بندی روزانه → **همه در لایه‌ی Supabase شما پیاده می‌شود** (§۹)
(منابع: [docs.zernio.com/webhooks](https://docs.zernio.com/webhooks)، [docs.zernio.com/comment-automations](https://docs.zernio.com/comment-automations/create-comment-automation))

### 6.3 سند بودجه‌ی پیام — ۷ اهرم برای ماندن زیر ۱۰هزار

فرض: ۵۰۰ تا ۱٬۰۰۰ رویداد ورودی در روز (ترکیب دایرکت + کامنت). بودجه‌ی هدف: **≤ ۳۰۰ ارسال دایرکت در روز** (≈ ۹٬۰۰۰/ماه، با ۱۰٪ حاشیه امنیت).

| # | اهرم | مکانیزم | صرفه‌جویی تخمینی |
|---|---|---|---|
| ۱ | **کانال‌سوئیچینگ به کامنت (بزرگ‌ترین اهرم)** | هر سؤالی که در **کامنت** آمده با **ریپلای عمومی** پاسخ بده (رایگان/نامحدود). دایرکت را برای موارد خصوصی (قیمت عمده، آدرس، سفارش) نگه دار. در Comment-to-DM هم می‌توانی `commentReply` عمومی (رایگان) را بفرستی و `dmMessage` را فقط برای کلیدواژه‌های پولی فعال نگه داری. | ۳۰–۵۰٪ حجم |
| ۲ | **فیلتر اسپم/سلام‌تکراری (قبل از LLM)** | Regex + لیست کلمات فارسی/انگلیسی + تشخیص لینک اسپم در SQL. پیام‌های «سلام»/«درود»/ایموجی‌تنها → پاسخ تمپلیتِ بدون LLM یا لایک/بدون پاسخ. پیام تکراری همان کاربر در بازه‌ی X ساعت (هش نرمال‌شده) → بدون پاسخ. | ۲۰–۳۵٪ |
| ۳ | **کول‌داون به ازای هر کاربر** | حداکثر N پاسخ خودکار در روز به یک `@sender` (پیشنهاد: ۳). بعد از آن → صبر سکوت یا مسیریابی به تلگرام ادمین. | ۱۰–۱۵٪ |
| ۴ | **رد کردن رویدادهای غارسزون** | `reaction.received`، `message.read`، story mention خالی → هرگز پاسخ دایرکت نده. | ۵–۱۰٪ |
| ۵ | **اجتناب از Broadcast** | هر گیرنده‌ی broadcast یک پیام مترشده است؛ ۵٬۰۰۰ گیرنده = نیمی از بودجه‌ی ماه! خبر/کمپین را روی پست/استوری (رایگان) و تمپلیت «کامنت کنید لینک بیاید» سوار کن. | صدمه‌زننده در صورت بی‌توجهی |
| ۶ | **گیت بودجه‌ی روزانه‌ی نرم (Budget Gate)** | شمارنده‌ی `sent_count` ماه‌جاری در Supabase؛ وقتی به ۸۵٪ رسید → حالت صرفه‌جویی: فقط پاسخ به سؤالات «قصد خرید» (نیت‌شناسی LLM)، بقیه به تلگرام ادمین. + چک کراس با `GET /v1/usage` خود Zernio در کرون روزانه. | جلویسرپرایز آخر ماه |
| ۷ | **فیوز سخت (بدون کارت)** | کارت بانکی به Zernio نده → در ۱۰٬۰۰۰ ارسال fail می‌شود، هزینه‌ای ایجاد نمی‌شود. با هشدار ۷٬۵۰۰ هم سینک شو (webhook/BCC ایمیل یا کرون روزانه). | **ضمانت ریاضی صفر دلار** |

(مرجع usage endpoint و plumbing: [github.com/zernio-dev](https://github.com/zernio-dev))

### 6.4 ریسک‌نامه‌ی متا (مهم برای سلامت اکانت فروشگاهی)

| ریسک | سقف رسمی/عملی ۲۰۲۶ | اقدام پیشگیرانه در معماری |
|---|---|---|
| DM/hour | ~۲۰۰ دایرکت خودکار در ساعت (عملی) | Pacer در صف: حداکثر ۶۰–۱۰۰/ساعت برای اکانت جوان، توزیع زمانی با `scheduled_at` |
| Private Reply به کامنت | ۷۵۰/ساعت، **فقط ۱ بار به ازای هر کامنت، در پنجره‌ی ۷ روزه** | علامت `private_reply_used=true` روی رکورد کامنت |
| پنجره‌ی پیام‌رسانی | ۲۴ ساعت برای پیام تبلیغاتی؛ تگ‌های `CONFIRMED_EVENT_UPDATE` و... از **آوریل ۲۰۲۶ حذف شده‌اند** | Zernio خودش پنجره را هندل می‌کند (تگ مجاز: فقط `HUMAN_AGENT`)؛ پاسخ‌ها را سریع از صف شلیک کن (هدف <۲ دقیقه) |
| High-volume inbox | با ~۷۲٬۰۰۰ پیام ارسالی+دریافتی، Inbox اینستاگرام موقتاً قفل می‌شود | حجم شما خیلی پایین‌تر است؛ صرفاً بدانید |
| ابزارهای غیررسمی | تشخیص موج‌وار ۲۰۲۶ | شما صفر ریسک دارید: Zernio مسیر رسمی است |
| محرمانگی داده در LLM رایگان | گوگل ممکن است داده‌ی لایه‌ی رایگان را برای آموزش ببرد | در پرامپت فقط متن سؤال بفرستید، نه دیتای سفارش؛ یا Groq (بدون آموزش‌داده) را اصلی کنید |

(منابع: [ReplyRush: قوانین متا ۲۰۲۶](https://www.replyrush.com/post/is-instagram-dm-automation-safe-1)، [PostZen: محدودیت‌های API](https://www.postzen.dev/blog/instagram-api-pricing)، [Conferbot: سقف‌های مستند](https://www.conferbot.com/limits/instagram)، [Zernio send message docs](https://docs.zernio.com/messages/send-inbox-message)، [DMCompared: تغییرات ۲۰۲۶](https://dmcompared.com/explained/instagram-automation-trends/))

---

## 7. پاسخ سؤال ۵: پل رایگان تلگرام ←→ اینستاگرام (بدون هیچ محدودیت مؤثر)

### 7.1 معماری «پل انسانی + هوش مصنوعی»

ایده: **تلگرام رایگان و نامحدود است؛ Zernio خواندن را رایگان و نامحدود کرده؛ پس تنها منبع کمیابِ سیستم «ارسال دایرکت» است.** پل را طوری بساز که این منبع فقط صرف پیام‌های باارزش شود:

```
┌─────────────────────────────────────────────────────────────────┐
│  دایرکت/کامنت اینستاگرام ──webhook──▶ Vercel                     │
│      │                                                          │
│      ├─▶ [A] ارزش پاسخ خودکار دارد؟                             │
│      │      ├─ بله + بودجه هست ─▶ LLM/تمپلیت ─▶ Zernio send     │
│      │      └─ خیر ─▶ [B]                                       │
│      │                                                          │
│      └─▶ [B] فوروارد به چت تلگرام ادمین (رایگان، نامحدود):       │
│             «پیام از @user: «قیمت ست ۳ تیکه چنده؟»              │
│             [ پاسخ سریع ] [ پاسخ با AI ] [ بی‌خیال ] [ بلاک ]»  │
│                          │                                      │
│      ادمین در تلگرام ریپلای می‌کند (یا دکمه AI) ─▶ Zernio send  │
└─────────────────────────────────────────────────────────────────┘
```

- خواندن: نامحدود/رایگان. فوروارد به تلگرام: رایگان/نامحدود (۳۰ msg/s کافی است).
- ارسال: فقط برای پاسخ‌های تأییدشده (خودکار یا انسانی) از بودجه‌ی ۱۰هزار مصرف می‌شود.
- با میانگین پاسخ انسانی، حجم ارسال واقعی معمولاً به ۳۰–۶۰٪ حجم ورودی می‌رسد → اساساً نامحدود عملیاتی.

### 7.2 ترفند خلاقانه‌ی دوم: دو اپ تأییدشده‌ی موازی (Multi-App Split)

متا اجازه می‌دهد **چند ابزار تأییدشده** هم‌زمان به یک اکانت Business وصل باشند (Settings → Messages → Connected tools). پس:

- **QuickDM رایگان** (۲۰ دایرکت/ساعت، نامحدود ماهانه، بدون کارت) ← فقط برای **کمپین‌های کلیدواژه‌ای comment-to-DM** («بفرست قیمت») و Welcome DM.
- **Zernio stack** ← مکالمات ارزشمند، پاسخ‌های LLM، مدیریت اسپم، آنالیتیکس.

نتیجه: پاسخ‌های کلیدواژه‌ای پرتکرار (که بزرگ‌ترین مصرف‌کننده‌ی سهمیه بودند) روی متر رایگان QuickDM می‌روند و سهمیه‌ی ۱۰هزارتایی Zernio برای گفت‌وگوهای واقعی آزاد می‌ماند.
**احتیاط:** هر دو اپ وب‌هوک‌های یک اکانت را می‌گیرند؛ دامنه‌ی مسئولیت را با کلیدواژه جدا کنید (QuickDM فقط پست‌های کمپین، Zernio بقیه) تا ریپلای دوبل نخورید. ریسک بلاک: پایین — هر دو مسیر رسمی‌اند و مجموع نرخ باید زیر ~۲۰۰ DM/h بماند.
(منابع: [QuickDM free plan](https://quickdm.app/blog/best-instagram-dm-automation-tools)، [QuickDM rate limits](https://quickdm.app/blog/instagram-comment-to-dm-automation-complete-guide)، [FlowGent: connected tools](https://flowgent.ai/blog/instagram-dm-automation))

### 7.3 ترفند سوم: Meta Business Suite به‌عنوان لایه‌ی انسانی رایگان

اپ/وب رسمی خود متا — بدون هیچ اپ دیوелپری. برای پاسخ‌های دستی ادمین در ساعات اوج، «پاسخ ذخیره‌شده» و away message. محدودیت‌ها: ۵ کلیدواژه‌ی دقیق، تأخیر ۱۵ دقیقه‌ای اتومیشن، comment-to-DM فقط دسکتاپ → مکمل است نه ستون اصلی.
(منبع: [Blotato: Meta Business Suite](https://www.blotato.com/blog/instagram-automation-tools))

---

## 8. جدول مقایسه ۳ گزینه برتر

| معیار | **گزینه ۱ (برنده): Zernio + لایه‌ی خودتان** | **گزینه ۲: SocialAPI.ai Hobby** | **گزینه ۳: QuickDM Free (no-code)** |
|---|---|---|---|
| هزینه‌ی ماهانه در حجم شما | **۰ دلار** (بدون کارت = سقف سخت ۱۰هزار) | ۰ دلار (اما فقط ۵۰ ارسال/ماه) | ۰ دلار |
| پلن رایگان دائمی | ✅ ۲ اکانت، بدون کارت | ✅ ۲ پروفایل، بدون کارت | ✅ بدون کارت |
| خواندن پیام | نامحدود + وب‌هوک لحظه‌ای | نامحدود + وب‌هوک | داخل اپ خودش |
| ارسال دایرکت | **۱۰٬۰۰۰/ماه رایگان**، بعد ۱$/10k | ۵۰/ماه | ۲۰/ساعت (≈ ۴۸۰/روز) |
| پاسخ به کامنت | **نامحدود و رایگان** | جزو ۵۰ تا interaction | نامحدود (با نرخ ۲۰/ساعت) |
| API برای ربات شما | ✅ کامل + SDK + CLI | ✅ کامل | ❌ |
| Webhook به Vercel | ✅ امضادار + retry | ✅ | ❌ |
| MCP | ✅ رایگان | ✅ رایگان | ❌ |
| اتصال LLM خودتان | ✅ | ✅ | ❌ (rule-based) |
| دیتا/مالکیت مکالمه | در Supabase شما | در Supabase شما | در پنل آن‌ها |
| نیاز به اپ متا | ❌ | ❌ | ❌ |
| نیاز به سرور/VPS | ❌ | ❌ | ❌ |
| ریسک برای اکانت | بسیار پایین (مسیر رسمی متا) | بسیار پایین (مسیر رسمی) | پایین (رسمی، ولی نرث سقف ۲۰/ساعت) |
| سناریوی مناسب | **پیاده‌سازی اصلی شما** | failover خواندن / اکانت دوم | کمپین‌های کلیدواژه‌ای موازی |

**حکم نهایی:** گزینه‌ی ۱ به‌تنهایی کل نیاز را در ۰ دلار پوشش می‌دهد؛ گزینه‌های ۲ و ۳ را به‌عنوان «افزودنی رایگان» در کنارش بکار گیرید (نه جایگزین).

---

## 9. معماری فنی پیشنهادی (نقشه پیاده‌سازی کامل)

### 9.1 نمای کلی کامپوننت‌ها

```
                         ┌─────────────┐
                         │  Instagram   │
                         └──────┬───────┘
                Meta approved app (Zernio)
                                │ webhooks: message.received / comment.received
                                ▼
┌────────────────────────────────────────────────────────────────────┐
│  Vercel (FastAPI) — تماماً stateless                                │
│ ────────────────────────────────────────────────────────────────│
│  POST /api/webhooks/zernio                                        │
│    1) verify HMAC signature (سکرت خودتان در /v1/webhooks/settings) │
│    2) dedupe با event_id (INSERT ... ON CONFLICT DO NOTHING)      │
│    3) پاسخ 200 در <300ms → پردازش با BackgroundTasks (waitUntil)  │
│                                                                     │
│  Dispatcher:                                                        │
│    comment.received ──▶ CommentEngine (ریپلای عمومی: رایگان/نامحدود)│
│    message.received ──▶ DMEngine (صرفه‌جویی‌محور + LLM + بودجه)     │
│    reaction/read/... ──▶ فقط لاگ                                    │
│                                                                     │
│  POST /api/webhooks/telegram  ← دکمه‌ها و ریپلای‌های ادمین          │
│  GET  /api/cron/daily-report  ← Vercel Cron 1/day                   │
└──────────────────────┬──────────────────────────┬─────────────────┘
                       │                          │
                       ▼                          ▼
               Supabase (Postgres)          Zernio REST API
               صف، بودجه، لاگ،              send DM / reply comment /
               تمپلیت، blacklist            hide-comment / private-reply
```

### 9.2 اسکیمای Supabase (DDL)

```sql
-- رویدادهای خام وب‌هوک (برای dedupe و دیباگ)
create table ig_events (
  event_id      text primary key,
  type          text not null,              -- message.received | comment.received | ...
  payload       jsonb not null,
  received_at   timestamptz default now()
);

-- مکالمه‌ها و مخاطب‌ها
create table ig_contacts (
  sender_id     text primary key,           -- instagram-scoped id
  username      text,
  is_blocked    boolean default false,
  auto_replies_today int default 0,
  last_auto_reply_at timestamptz,
  conversation_id text                      -- Zernio conversation id از payload
);

-- صف پاسخ (قلب سیستم)
create table reply_queue (
  id            bigint generated always as identity primary key,
  kind          text not null,              -- 'dm' | 'comment_public' | 'comment_private'
  sender_id     text references ig_contacts(sender_id),
  conversation_id text,
  comment_id    text,
  post_id       text,
  inbound_text  text,
  msg_hash      text,                       -- هش نرمال‌شده برای تشخیص تکراری
  intent        text,                       -- خروجی classifier: buy|price|spam|greeting|other
  reply_text    text,
  status        text default 'pending',     -- pending|approved|sent|skipped|failed|human
  scheduled_at  timestamptz default now(),  -- pacer
  sent_at       timestamptz,
  error         text
);

-- شمارنده‌ی بودجه‌ی ماهانه (سینگلتون)
create table send_budget (
  year_month    text primary key,           -- '2026-10'
  sent_count    int default 0,
  soft_cap      int default 8500,           -- گیت نرم ۸۵٪
  hard_cap      int default 9800            -- بقیه برای ادمین/اضطرار
);

-- تمپلیت‌های FAQ (پاسخ بدون LLM)
create table faq_templates (
  id          bigint generated always as identity primary key,
  pattern     text not null,                -- regex فارسی: '(قیمت|چند|چنده).*(ست|سرهمی)'
  answer_fa   text not null,
  active      boolean default true
);
```

### 9.3 جریان پردازش DMEngine (سودوکد نزدیک به کد)

```python
# در BackgroundTask بعد از 200 OK
async def handle_dm(evt):
    contact = upsert_contact(evt.sender)                       # رایگان
    if contact.is_blocked:            return log('skipped')    # اهرم ۳/بلاک
    if is_duplicate(evt.text, contact): return log('skipped')  # اهرم ۲ (هش+TTL 6h)
    if near_cap():                    return forward_to_telegram(evt)  # اهرم ۶

    intent = classify(evt.text)        # regex اول؛ LLM فقط اگر مبهم  (اهرم ۲)
    if intent == 'spam':               return block_or_ignore(contact)
    if intent == 'greeting':           reply = random_greeting_template()   # بدون LLM
    elif intent in FAQ_MATCH:          reply = faq_templates[intent]        # بدون LLM
    else:
        reply = await llm_chain(       # اهرم LLM رایگان با fallback
            evt.text,
            providers=[gemini_flash, groq_120b, mistral_small])
        reply = safety_check(reply)    # فیلتر قیمت/وعده‌ی غلط؛ در غیر اینصورت → telegram

    ok = await zernio_send(conversation_id=evt.conversation_id, text=reply)
    # POST {ZERNIO}/v1/inbox/conversations/{id}/messages
    if ok: increment_budget()                      # فقط وقتی 200 گرفتیم
    else:  await pacer_retry_or_human(evt)         # 429 → صف با scheduled_at+5min
```

### 9.4 جریان CommentEngine (رایگان/نامحدود = بدون ملاحظه‌ی بودجه)

```python
async def handle_comment(evt):
    if evt.text matches SPAM:        await zernio_hide_comment(evt.comment_id)   # رایگان
    elif is_question(evt.text):
        reply = template_or_llm(evt.text)
        await zernio_reply_comment(post_id, comment_id, reply)                   # رایگان، نامحدود
        # فقط اگر کاربر «لینک/قیمت عمده» خواست:
        if intent == 'needs_dm' and not private_reply_used(comment):
            await zernio_private_reply(comment_id, dm_text)  # ← این یکی متر می‌شود
```

### 9.5 تخلیه‌ی صف بدون سرور همیشه‌روشن (مهم‌ترین نکته‌ی Serverless)

Vercel Hobby فقط **۱ اجرای کرون در روز** می‌دهد — برای صف لحظه‌ای کافی نیست. راه‌حل ترکیبی صفرهزینه:

1. **پردازش In-line در همان وب‌هوک** (۹۰٪ موارد): وب‌هوک که می‌رسد، همان‌جا در `BackgroundTasks` کل زنجیره (کلاس‌بندی → تولید → ارسال) اجرا می‌شود. نیازی به کرون نیست. زمان کل < ۳۰ ثانیه زیر سقف ۳۰۰ ثانیه‌ی Hobby.
2. **تلگرام به‌عنوان «ضربان قلب»**: ادمین که در تلگرام دکمه می‌زند، همان فراخوانی، صف `pending+scheduled_at<=now()` را هم یک دور تخلیه می‌کند.
3. **Vercel Cron روزانه**: گزارش مصرف (`GET /v1/usage` + شمارش Supabase)، ریست `auto_replies_today`، پاک‌سازی رویدادهای قدیمی (نگه‌داشتن DB زیر ۵۰۰MB)، و Keep-alive پینگ به Supabase.
4. (اختیاری) **Supabase `pg_cron`** رایگان است و روی free tier کار می‌کند؛ می‌توان هر ۱۵ دقیقه رکوردهای `stale` صف را فلگ کرد و با Edge Function تخلیه کرد — اگر روزی حجم بالا رفت.
(منابع: [Vercel cron limits](https://vercel.com/docs/cron-jobs/usage-and-pricing)، [pg_cron روی free tier](https://runhooks.app/blog/preventing-supabase-free-tier-pausing/))

### 9.6 متغیرهای محیطی

```
ZERNIO_API_KEY=...            # از داشبورد Zernio
ZERNIO_WEBHOOK_SECRET=...     # خودتان تعریف می‌کنید و همان را در /v1/webhooks/settings می‌دهید
TELEGRAM_BOT_TOKEN=...
TELEGRAM_ADMIN_CHAT_ID=...
SUPABASE_URL=... / SUPABASE_SERVICE_KEY=...
GEMINI_API_KEY=...  GROQ_API_KEY=...  MISTRAL_API_KEY=...   # هر سه لایه رایگان
```

### 9.7 نقشه‌ی راه پیاده‌سازی (۵ فاز، ~۲–۳ روز کدنویسی)

| فاز | کار | معیار قبولی |
|---|---|---|
| ۱ | Subscribe وب‌هوک Zernio + ذخیره‌ی خام در `ig_events` + Forward به تلگرام | هر دایرکت/کامنت در <۵ ثانیه در تلگرام دیده شود |
| ۲ | پل انسانی (دکمه‌های ریپلای/بلاک/AI) | پاسخ ادمین از تلگرام به دایرکت برسد و در بودجه ثبت شود |
| ۳ | CommentEngine (ریپلای عمومی + hide اسپم) | پاسخ خودکار کامنت‌ها بدون مصرف بودجه |
| ۴ | DMEngine: تمپلیت FAQ + classifier + LLM chain + Pacer | ۹۰٪ پاسخ‌ها خودکار، مصرف روزانه <۳۰۰ |
| ۵ | Budget gate + کرون گزارش روزانه + تست فیوز | شبیه‌سازی ۱۰هزار ارسال: سیستم در ۹٬۸۰۰ به حالت انسانی سوئیچ کند |

### 9.8 محاسبه‌ی نهایی هزینه (سناریوی بدترین حالت)

| سناریو | ارسال/ماه | هزینه‌ی Zernio | LLM | Vercel | Supabase | مجموع |
|---|---|---|---|---|---|---|
| امروز شما (۵۰۰ ورودی/روز، ۵۰٪ اتوماسیون) | ~۷٬۵۰۰ | **۰$** | ۰$ | ۰$ | ۰$ | **۰$** |
| رشد (۸۰۰ ورودی/روز، ۴۰٪ اتوماسیون) | ~۹٬۶۰۰ | **۰$** | ۰$ | ۰$ | ۰$ | **۰$** |
| وایرال (۱٬۰۰۰/روز، گیت بودجه فعال) | ۹٬۸۰۰ + مابقی انسانی | **۰$** (فیوز بدون کارت) | ۰$ | ۰$ | ۰$ | **۰$** |
| اگر کارت بدهید و بی‌مهابا به همه پاسخ دهید | ~۳۰٬۰۰۰ | ۲$ | ۰$ | ۰$ | ۰$ | ۲$ (سقف فاجعه!) |

---

## 10. ریسک‌ها و محدودیت‌های پلتفرمی

1. **وابستگی به تک‌پروایدر (Zernio):** کل تخم‌مرغ‌ها در یک سبد است. کاهش ریسک: خروجی am Data در Supabase خودتان است، و SocialAPI.ai Hobby را به‌عنوان «لایه‌ی خواندن رزرو» از حالا وصل کنید (OAuth دیگری، ۰ دلار) تا اگر وب‌هوک Zernio قطع شد حداقل با polling رایگان پیام‌ها را بخوانید.
2. **تغییر قیمت آینده:** متر ۱۰هزارتایی Zernio تازه (۱ اکتبر ۲۰۲۶) فعال شده؛ سیاست «بدون کارت = توقف سخت» را هر فصل از [docs.zernio.com/pricing](https://docs.zernio.com/pricing) چک کنید.
3. **تحریم و اکانت‌سازی:** ثبت‌نام/پرداخت در سرویس‌های آمریکایی از ایران ریسک خودش را دارد (شما الان Zernio را دارید پس عملی است). همان قانون برای SocialAPI.ai و QuickDM صدق می‌کند — تست با ایمیل سازمانی و بدون کارت. خود Google AI Studio گاهی برای IP ایران سخت‌گیری می‌کند؛ API key را یک‌بار بسازید و سرور Vercel (IP خارج) صدا می‌زند، پس ریسک عملیاتی پایین است. Groq/Mistral fallback هستند.
4. **کیفیت پاسخ LLM رایگان:** مدل رایگان ممکن است قیمت/موجودی اشتباه «هالوسینیت» کند → قانون طلایی: هر پاسخ حاوی عدد/قیمت فقط از جدول محصولات (context تزریقی) یا تأیید انسانی.
5. **محدودیت ۲۴ ساعته و حذف تگ‌ها (آوریل ۲۰۲۶):** فالو-آپ تبلیغاتی بعد از ۲۴ ساعت از آخرین پیام کاربر ممکن نیست؛ Zernio پنجره را هندل می‌کند ولی صف شما هم باید `scheduled_at` را در همان پنجره نگه دارد.
6. **Vercel Hobby برای استفاده‌ی تجاری** (گفته شد در §۵.۳) — تمیزترین مسیر بلندمدت صفرهزینه: انتقال پردازشگر وب‌هوک به Supabase Edge Functions.

---

## 11. منابع

**Zernio (رسمی):**
1. قیمت‌گذاری: https://zernio.com/pricing و https://docs.zernio.com/pricing
2. حذف پلن‌ها و شامل‌بودن همه‌ی فیچرها: https://zernio.com/blog/pay-per-account-pricing
3. وب‌هوک‌های Inbox و رویدادها: https://docs.zernio.com/webhooks/inbox و https://docs.zernio.com/webhooks
4. قابلیت‌های اینستاگرام (DM/کامنت/private-reply/webhook): https://docs.zernio.com/platforms/instagram
5. ارسال پیام و قوانین pacing: https://docs.zernio.com/messages/send-inbox-message
6. Comment-to-DM automation: https://docs.zernio.com/comment-automations/create-comment-automation و https://zernio.com/comment-to-dm
7. کامنت‌ها نامحدود/رایگان: https://zernio.com/social-media-comments
8. MCP: https://zernio.com/instagram-mcp
9. CLI/اندپوینت‌ها (usage metering): https://github.com/zernio-dev
10. Changelog (رفتار private-reply): https://docs.zernio.com/changelog

**تحلیل‌های مستقل Zernio:**
11. https://droidcrunch.com/zernio-pricing/ (شامل مکانیزم هشدار ۷٬۵۰۰ و توقف در ۱۰٬۰۰۰ بدون کارت)
12. https://www.blotato.com/blog/zernio-pricing

**گزینه‌های دیگر:**
13. SocialAPI.ai: https://social-api.ai/pricing و https://social-api.ai/blog/free-social-media-api-2026
14. بدون اپ متا (مقایسه‌ی ۳ مسیر تأییدشده): https://social-api.ai/blog/instagram-facebook-api-without-meta-app-review
15. Ayrshare: https://www.ayrshare.com/pricing/ ، https://www.ayrshare.com/social-media-messenger-apis/ ، تحلیل مستقل: https://social-api.ai/blog/ayrshare-pricing-social-media-api-2026
16. ChatbotX: https://chatbotx.io/pricing/ ، https://chatbotx.io/channels/instagram/
17. Buffer API: https://support.buffer.com/article/859-does-buffer-have-an-api ، https://buffer.com/api
18. Publer: https://publer.com/help/en/article/what-are-publers-plans-and-pricing-15h4yqh/
19. QuickDM: https://quickdm.app/blog/best-instagram-dm-automation-tools ، https://quickdm.app/blog/instagram-comment-to-dm-automation-complete-guide
20. پلن‌های رایگان DM: https://www.reeldrop.io/blog/best-instagram-dm-automation-tools/ ، https://creatorflow.so/blog/free-instagram-dm-automation-tools/ ، https://www.companionlink.com/blog/2026/09/7-best-instagram-dm-automation-tools-in-2026/
21. Open-source و هزینه‌ی واقعی self-host: https://creatorflow.so/blog/open-source-instagram-dm-automation/

**قوانین و سقف‌های متا (۲۰۲۶):**
22. https://www.replyrush.com/post/is-instagram-dm-automation-safe-1
23. https://www.postzen.dev/blog/instagram-api-pricing (۷۵۰ private-reply/ساعت)
24. https://www.conferbot.com/limits/instagram (سقف ۷۲هزار پیام Inbox)
25. https://dmcompared.com/explained/instagram-automation-trends/ (حذف تگ‌ها آوریل ۲۰۲۶)
26. https://flowgent.ai/blog/instagram-dm-automation (Connected tools / چند اپ موازی)

**زیرساخت رایگان:**
27. Vercel: https://vercel.com/docs/plans/hobby ، https://vercel.com/docs/cron-jobs/usage-and-pricing ، https://vercel.com/pricing
28. Supabase: https://supabase.com/pricing ، https://supabase.com/docs/guides/functions/limits ، https://runhooks.app/blog/preventing-supabase-free-tier-pausing/
29. LLM رایگان: https://tokenmix.ai/blog/gemini-api-free-tier-limits ، https://www.memetik.ai/guides/gemini-api-free-tier-limits ، https://openrouter.ai/blog/tutorials/free-llm-apis-compared/ ، https://www.edenai.co/post/top-free-generative-ai-apis-and-open-source-models

---

> **جمع‌بندی یک‌جمله‌ای:** پاسخ شما «خرید ابزار جدید» نیست؛ **تسلط بر مترِ پیامِ ابزاری است که همین حالا دارید** — وب‌هوک رایگان Zernio به Vercel، مغز LLM رایگان، قلب Supabase، پل انسانی تلگرام، کامنت‌های نامحدود رایگان، و فیوزِ «بدون کارت» — حاصلش: صفر دلار، صفر ریسک صورتحساب، و ظرفیت عملی نامحدود.
